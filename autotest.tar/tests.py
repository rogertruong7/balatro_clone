#!/usr/bin/env python3
from cs6991 import test
import os
import sys

test.init(__file__, compile_commands=["./check_mark_request.sh #"])

def process_dir(dir_path):
    for file in os.listdir(dir_path):
        full_path = os.path.join(dir_path, file)
        if os.path.isdir(full_path):
            process_dir(full_path)
        elif file.endswith(".yml"):
            print(f"Generating test for {file}", file=sys.stderr)
            test.case("", args=[full_path])

process_dir("fixtures")
